var http=require('http');
var fs=require('fs');
var readData=(req,res)=>
{
    fs.readFile('employeeList.txt',function(key,data)
    {
        res.writeHead(200,{'Content-Type':'text/html'});
        console.log(data.toString());   
    });
}

http.createServer(readData).listen(8000);