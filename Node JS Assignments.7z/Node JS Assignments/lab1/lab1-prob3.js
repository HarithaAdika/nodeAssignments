var http=require('http');
var fs=require('fs');
var readData=(req,res)=>
{
    fs.writeFile('emp.txt','this is text file' ,function(err,r){
        if(err) throw err;
        console.log("Hii");
    });
}

http.createServer(readData).listen(8000);