var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
 var http=require('http');

/* -----Inserting the data ---------*/
 MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var prodList = [
    { prodId:1,prodName: 'Laptop', cost:40000,prodDescription:"Good"},
    { prodId:2,prodName: 'TV', cost:45000,prodDescription:"Excellent"},
    { prodId:3,prodName: 'Hard disk', cost:4000,prodDescription:"Average"},
    { prodId:4,prodName: 'Camera', cost:80000,prodDescription:"Bad"}
  ];
  dbo.collection("products").insertMany(prodList, function(err, res) {
    if (err) throw err;
    console.log("Number of products inserted: " + res.insertedCount);
    db.close();
  });
});

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  
  dbo.collection("products").find({}).toArray(function(err, result) {
    if (err) throw err;  
    console.log("-----Get All Data---------");  
    console.log(result);
    db.close();
  });
});

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  
  var myquery={"prodId":3};
  dbo.collection("products").find(myquery).toArray(function(err, result) {
    if (err) throw err;
    console.log("-----------Get Data for Particular Id------------");
    console.log(result);
    db.close();
  });
});

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var myquery = { "prodId":2};
  dbo.collection("products").deleteOne(myquery, function(err, obj) {
    if (err) throw err;
    console.log("Deleting Data based on product Id");
    console.log(" 1 product deleted");
    db.close();
  });
});
/*
MongoClient.connect(url,function(err,db){
    if(err) throw err;
    var dbo=db.db("mydb");
    var myquery={prodId:6,prodName: 'Refrigirator', cost:20000,prodDescription:"Excellent"};
    dbo.collection("products").insertOne(myquery, function(err, res) {
    if (err) throw err;
    console.log("Number of products inserted: " + res.insertedCount);
    db.close();
  });
})*/
/*---- updating the data based on Product Id-----------*/
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var myquery = { "prodId":6 };
  var newvalues = { $set: {rating:4.5 } };
  dbo.collection("products").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
});
