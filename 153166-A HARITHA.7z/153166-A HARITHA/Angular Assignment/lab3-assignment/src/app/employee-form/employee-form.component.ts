import { Component, OnInit } from '@angular/core';
import {NgForm,Validator,FormBuilder,FormGroup} from '@angular/forms'
@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent implements OnInit {
Id:number;
name:string;
Cost:number;
Online:string;
category:string;
Store:string;
emp:any;
categories=['Grocery', 'Mobile', 'Electronics','Cloths'];
submitEmpForm(emp:NgForm){
  console.log(this.Id+" "+this.name+" "+this.Cost+" "+this.Online+" "+this.category+" "+this.store);

}
  constructor() { }

  ngOnInit() {
  }
  store:any=[];
test(event){
this.store.push(event.target.defaultValue);
}
}
