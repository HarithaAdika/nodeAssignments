export class Employee {

  constructor(
    public id: number,
    public name: string,
    public category: string,
    public cost:number,
    public online:string,
    public available: string
  ) {  }

}