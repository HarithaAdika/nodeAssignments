import { Component, OnInit } from '@angular/core';
import {Books} from '../books';
import {BookServiceService} from '../book-service.service'
@Component({
  selector: 'app-lab4-prob1',
  templateUrl: './lab4-prob1.component.html',
  styleUrls: ['./lab4-prob1.component.css']
})
export class Lab4Prob1Component implements OnInit {

  constructor(private bookserviceService:BookServiceService) { }
book:Books[];
getBooklist():void{
  this.bookserviceService.getBooklist().subscribe((book:Books[])=>this.book=book);
}
  ngOnInit() {
      this.getBooklist();
  }

}
