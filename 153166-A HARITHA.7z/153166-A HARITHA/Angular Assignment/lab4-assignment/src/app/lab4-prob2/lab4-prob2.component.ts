import { Component, OnInit } from '@angular/core';
import {Books} from '../books';
import {BookServiceService} from '../book-service.service'
import {BookFilterPipe} from './bookfilter.pipe'
@Component({
  selector: 'app-lab4-prob2',
  templateUrl: './lab4-prob2.component.html',
  styleUrls: ['./lab4-prob2.component.css'],

})
export class Lab4Prob2Component implements OnInit {
book:Books[];

filter: Books = new Books();

  constructor(private bookserviceService:BookServiceService) {
   
   }
getBooklist():void{
  this.bookserviceService.getBooklist().subscribe((book:Books[])=>this.book=book);
}
  ngOnInit() {
    this.getBooklist();
  }

}
