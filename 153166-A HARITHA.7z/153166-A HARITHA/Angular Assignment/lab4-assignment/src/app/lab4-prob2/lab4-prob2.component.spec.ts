import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab4Prob1Component } from './lab4-prob1.component';

describe('Lab4Prob1Component', () => {
  let component: Lab4Prob1Component;
  let fixture: ComponentFixture<Lab4Prob1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab4Prob1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab4Prob1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
