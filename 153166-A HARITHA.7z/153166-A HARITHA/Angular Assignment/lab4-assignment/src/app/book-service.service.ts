import { Injectable } from '@angular/core';
import {Books} from './books';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class BookServiceService {
booklistUrl='assets/booklists.json';
  constructor(private http: HttpClient) { }
  getBooklist(){
     return this.http.get<Books[]>(this.booklistUrl)

  }
}
