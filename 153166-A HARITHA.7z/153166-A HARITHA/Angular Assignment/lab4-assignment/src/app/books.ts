export class Books{
    id:number;
    title:string;
    author:string;
    year:number;
}