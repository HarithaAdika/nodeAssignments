import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule}  from '@angular/forms'
import { AppComponent } from './app.component';
import { Lab4Prob2Component } from './lab4-prob2/lab4-prob2.component';

import {HttpClientModule} from '@angular/common/http';
import {BookServiceService} from './book-service.service';
import { BookFilterPipe } from './lab4-prob2/bookfilter.pipe';
import { Lab4Prob1Component } from './lab4-prob1/lab4-prob1.component'
@NgModule({
  declarations: [
    AppComponent,
    Lab4Prob2Component,
    BookFilterPipe,
    Lab4Prob1Component
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
