import { Component } from '@angular/core';
import {Employee } from './Details';
import {Emp} from './mock-Employee';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  empDetail=Emp;
  sortById():void{

this.empDetail.sort(function(num1,num2)
{
if(num1.empId<num2.empId)
return -1;
if(num1.empId>num2.empId)
return 1;
return 0;
});
}
  sortByName():void{

this.empDetail.sort(function(a,b)
{
if(a.empName<b.empName)
return -1;
if(a.empName>b.empName)
return 1;
return 0;
});
}
  sortByDep():void{

this.empDetail.sort(function(a,b)
{
if(a.empDep<b.empDep)
return -1;
if(a.empDep>b.empDep)
return 1;
return 0;
});
}
  sortBySal():void{

this.empDetail.sort(function(n1,n2)
{
if(n1.empSal<n2.empSal)
return -1;
if(n1.empSal>n2.empSal)
return 1;
return 0;
});
}
}


