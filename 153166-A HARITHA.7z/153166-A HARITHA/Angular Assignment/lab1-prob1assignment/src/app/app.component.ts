import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 operation';
  userName:string;
  userId:number;
  userSalary:number;
  userDepartment:string;
  AddEmployee(){
    alert(this.userName+" "+this.userId+" "+this.userDepartment+" "+this.userSalary);
  }
}
