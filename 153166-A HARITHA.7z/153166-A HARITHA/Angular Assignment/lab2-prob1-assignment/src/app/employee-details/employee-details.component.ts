import { Component, OnInit } from '@angular/core';
import {Employee } from './employee';
import {Details} from './mock-employee';
@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  [x: string]: any;
  employee = Details;
  constructor() { }
  title="ADD EMPLOYEE";
  showdata="SHOW ALL EMPLOYEE";
  update="Update EMPLOYEE";
  ngOnInit() {
  }
  userId:number;
  userName:string;
  userSalary:number;
  userDepartment:string;
  e:any;
  addemp:any;
  pageTitle:string;
  empupdate:any;
  Id:number;
  Name:string;
  Salary:number;
  Department:string;
  AddEmployee(){

    this.pageTitle="DATA INSERTED";
    let addemp:Employee={empId:this.userId,empName:this.userName,empSal:this.userSalary,empDep:this.userDepartment};
    this.employee.push(addemp);
  }
  empUpdate(e){
    this.Id=e.empId;
    this.Name=e.empName;
    this.Salary=e.empSal;
    this.Department=e.empDep;
    this.empupdate=e;
    
  }
  UpdateEmp()
  {
this.pageTitle1="DATA UPDATED";
    this.empupdate.empId=this.Id;
    this.empupdate.empName=this.Name;
    this.empupdate.empSal=this.Salary;
    this.empupdate.empDep=this.Department;
  }
empDelete(key){
  this.pageTitle="DATA DELETED";
  this.employee.splice(key,1);

}
}
