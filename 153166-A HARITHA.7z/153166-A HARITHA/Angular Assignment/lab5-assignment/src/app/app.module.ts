import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RouterModule,Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { SearchMoviesComponent } from './search-movies/search-movies.component';
import { AddMoviesComponent } from './add-movies/add-movies.component';
const approuter:Routes=[
  {path:'add',component:AddMoviesComponent},
  {path:'search',component:SearchMoviesComponent},
  {path:'app',component:AppComponent},

];
@NgModule({
  declarations: [
    AppComponent,
    SearchMoviesComponent,
    AddMoviesComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(approuter),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
