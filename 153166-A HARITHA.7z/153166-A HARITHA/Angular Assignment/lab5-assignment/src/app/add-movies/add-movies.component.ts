import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
 import {FormsModule} from '@angular/forms'
@Component({
  selector: 'app-add-movies',
  templateUrl: './add-movies.component.html',
  styleUrls: ['./add-movies.component.css']
})
export class AddMoviesComponent implements OnInit {
genres=['Drama','Fiction','Satire'];


  constructor() { 
   
  }
  ngOnInit() {
  }

}
