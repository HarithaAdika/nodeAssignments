import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ProductService} from '../product.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
datArray:any[];

  constructor(private router:Router,private dataService: ProductService) {
    this.datArray= this.dataService.getUrlHistoryObj();
   
   
   }
billData(){
  this.router.navigate(['/bill']);
}
deleteData(data)
{
this.dataService.deleteArray(data);
}
  ngOnInit() {
    
  }



}
