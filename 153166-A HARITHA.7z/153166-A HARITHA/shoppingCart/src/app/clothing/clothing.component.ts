import { Component, OnInit } from '@angular/core';
import {Iclothing} from './cloth';
import{ProductService} from '../product.service'
@Component({
  selector: 'app-clothing',
  templateUrl: './clothing.component.html',
  styleUrls: ['./clothing.component.css']
})
export class ClothingComponent implements OnInit {
pageTitle="Clothing List";
 Cloth:Iclothing[];
 data:any;
  imageWidth:number=210;
  imageMargin:number=20;
  constructor(private ProductService:ProductService,private dataService: ProductService) { }

  ngOnInit() {
    this.getCloth();
  }
  getCloth():void{
this.Cloth=this.ProductService.getCloth();
  }
getClothing(data){
 this.dataService.setUrlHistoryObj(data);
  }
}
