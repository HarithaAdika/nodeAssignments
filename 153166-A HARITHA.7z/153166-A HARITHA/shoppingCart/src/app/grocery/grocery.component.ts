import { Component, OnInit } from '@angular/core';
import {Grocery} from './grocery';
import {ProductService} from '../product.service';


@Component({
  selector: 'app-grocery',
  templateUrl: './grocery.component.html',
  styleUrls: ['./grocery.component.css']
})
export class GroceryComponent implements OnInit {

 groceries:Grocery[];
 data:any;
  constructor(private productService:ProductService,private dataService: ProductService) { }
 getGrocery():void{
  this.groceries=this.productService.getGrocery();
 }
 groceryCart(data){
   this.dataService.setUrlHistoryObj(data);

 }
  ngOnInit() {
   this.getGrocery();
  }
 
}
