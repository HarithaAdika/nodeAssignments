import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { AccessoriesComponent } from './accessories/accessories.component';
import { GroceryComponent } from './grocery/grocery.component';
import { StationaryComponent } from './stationary/stationary.component';
import { ClothingComponent } from './clothing/clothing.component';
import { ProductComponent } from './product/product.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AppRoutingModule } from './app-routing.module';
import { CartComponent } from './cart/cart.component';
import { BillComponent } from './bill/bill.component';


@NgModule({
  declarations: [
    AppComponent,
    ElectronicsComponent,
    AccessoriesComponent,
    GroceryComponent,
    StationaryComponent,
    ClothingComponent,
    ProductComponent,
    LoginpageComponent, 
    WelcomeComponent, CartComponent, BillComponent
  ],
  imports: [
    BrowserModule,FormsModule, AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
