import { Component, OnInit } from '@angular/core';
import {Stationary} from './stationary';
import {ProductService} from '../product.service';
@Component({
  selector: 'app-stationary',
  templateUrl: './stationary.component.html',
  styleUrls: ['./stationary.component.css']
})
export class StationaryComponent implements OnInit {
data:any;
   stationaries:Stationary[];
  constructor(private productService:ProductService, private dataService: ProductService) { }
getStationaries():void{
  this.stationaries=this.productService.getStationaries();
}

  ngOnInit() {
    this.getStationaries();
  }
getStationary(data){  
this.dataService.setUrlHistoryObj(data);
}

}
