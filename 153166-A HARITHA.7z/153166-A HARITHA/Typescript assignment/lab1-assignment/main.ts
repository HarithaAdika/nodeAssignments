/// <reference path = "mobile.ts" />
/// <reference path = "basicPhone.ts" />
/// <reference path = "smartPhone.ts" />


var data =[
    {
        "mobileId":1000,
        "mobileName":"Samsung j7",
        "mobileCost":52000,
        "mobileType":"Android"
    },
    {
        "mobileId":2000,
        "mobileName":"IPhone",
        "mobileCost":64000,
        "mobileType":"IOS"
    }
]

function PrintDetails(phone){
    phone. printMobileDetails();
}

var basic = new Mobile.BasicPhoneDetails();
basic.mobileId=data[1].mobileId;
basic.mobileName=data[1].mobileName;
basic.mobileCost=data[1].mobileCost;
basic.mobileType=data[1].mobileType;
PrintDetails(basic);

var smart = new Mobile.SmartPhoneDetails();
smart.mobileId=data[0].mobileId;
smart.mobileName=data[0].mobileName;
smart.mobileCost=data[0].mobileCost;
smart.mobileType=data[0].mobileType;
PrintDetails(smart);
